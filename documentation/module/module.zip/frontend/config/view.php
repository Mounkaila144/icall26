<?php
// key = [action][view]
return array('all' => array('classView' => 'SmartyView',
    'widgets' => array('alerts'=>null),
),

    
); 
 
