<?php

// "blockName"= ....
return array(
    "default"=>array(
               "enabled"=>true,
           //    "cacheEnabled"=>true,
               "mode"=>"mixed"
                    ),
    
    
);